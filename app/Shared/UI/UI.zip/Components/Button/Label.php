<?php

declare(strict_types=1);

namespace ODE\Shared\UI\Components\Form;

use ODE\Shared\UI\Components\Element\Element;

final class Label extends Element
{
    protected string $tag = 'label';

    protected string $text = '';

    protected ?string $for = null;

    protected bool $required = false;

    public function __construct()
    {
        parent::__construct();

        $this->class('ode-label');
    }

    /**
     * Texto do label.
     */
    public function text(string $text): static
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Campo relacionado.
     */
    public function for(string $id): static
    {
        $this->for = $id;

        return $this;
    }

    /**
     * Marca como obrigatório.
     */
    public function required(bool $required = true): static
    {
        $this->required = $required;

        return $this;
    }

    public function render(): string
    {
        $text = htmlspecialchars(
            $this->text,
            ENT_QUOTES,
            'UTF-8'
        );

        if ($this->required) {
            $text .= ' <span class="ode-required">*</span>';
        }

        $this->content($text);

        if ($this->for !== null) {
            $this->attribute('for', $this->for);
        }

        return parent::render();
    }
}