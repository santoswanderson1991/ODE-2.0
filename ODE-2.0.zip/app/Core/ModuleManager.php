<?php

declare(strict_types=1);

namespace ODE\Core;

final class ModuleManager
{
    /**
     * @var object[]
     */
    private array $modules = [];

    public function __construct(
        private readonly Container $container
    ) {
    }

    public function register(object $module): self
    {
        if (method_exists($module, 'register')) {
            $module->register($this->container);
        }

        $this->modules[] = $module;

        return $this;
    }

    public function boot(): void
    {
        foreach ($this->modules as $module) {

            if (method_exists($module, 'boot')) {
                $module->boot($this->container);
            }
        }
    }
}